Copy the .pem file into your project directly. 

                    Please don't open it in a text editor as there is a chance that you will corrupt it.

                    The .pem file serves three main purposes:

                    - Decrypting the token we provide to your back-end when a user tries to log in.
                    - Signing your requests to our servers.
                    - Decrypting the fetched user profile so that it can be consumed by your application.